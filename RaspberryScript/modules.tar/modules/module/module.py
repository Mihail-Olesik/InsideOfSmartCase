class Module:
    def __init__(self, nameOfModule = 'module'):
        self.nameOfModule = nameOfModule

    def getData(self):
        pass

    def sendData(self, data):
        pass

    def closeConnection(self):
        pass

    def initializeConnection(self):
        pass